// SPDX-License-Identifier: GPL-3.0
pragma solidity ^0.8.17;

import "@tokenysolutions/t-rex/contracts/compliance/modular/IModularCompliance.sol";
import "@tokenysolutions/t-rex/contracts/token/IToken.sol";
import "@tokenysolutions/t-rex/contracts/compliance/modular/modules/AbstractModuleUpgradeable.sol";

/**
 * @title ForeignOwnershipCapModule
 * @notice Korea-specific compliance module (W3 / Module A).
 *
 *  Enforces a statutory foreign-ownership ceiling on a tokenized Korean stock
 *  (e.g. 49% for KT, 40% for KEPCO). Every unit of this token is assumed to be
 *  held by a foreign investor in this POC, so the "foreign held" amount equals
 *  the token totalSupply. In a fuller design, the module would read a per-holder
 *  nationality flag from the identity layer and only count foreign holders.
 *
 *  DESIGN NOTE (the W3 "mint trap"):
 *  ---------------------------------
 *  In standard T-REX, mint() checks identity but NOT the compliance modules on
 *  the value path in the same way a transfer does. This module closes that gap
 *  by treating a mint (detected as `_from == address(0)`) as an ownership-
 *  increasing event inside moduleCheck. A ModularCompliance runs canTransfer /
 *  its module bundle at mint time via moduleMintAction + the check wiring, so a
 *  mint that would breach the cap is rejected in code, not by custodian
 *  diligence. This is the single most important security property in the token
 *  layer for a Korean-equity wrapper.
 *
 *  The cap is expressed in absolute token units (the max foreign-held supply),
 *  supplied by an oracle/admin. Converting a percentage cap into an absolute
 *  unit cap is the network/oracle track's responsibility (aggregate foreign
 *  float feed); here we take the absolute cap directly for a self-contained demo.
 */
contract ForeignOwnershipCapModule is AbstractModuleUpgradeable {
    /// @dev compliance address => max foreign-held token supply (absolute units)
    mapping(address => uint256) private _cap;

    event ForeignCapSet(address indexed compliance, uint256 cap);

    function initialize() external initializer {
        __AbstractModule_init();
    }

    /**
     * @notice Set the absolute foreign-ownership cap (max total supply of this token).
     * @dev Callable only through the bound compliance contract (onlyComplianceCall).
     *      In production this value tracks an oracle feed of the aggregate foreign
     *      float for the underlying stock.
     */
    function setForeignCap(uint256 cap_) external onlyComplianceCall {
        _cap[msg.sender] = cap_;
        emit ForeignCapSet(msg.sender, cap_);
    }

    function getForeignCap(address compliance_) external view returns (uint256) {
        return _cap[compliance_];
    }

    /**
     * @notice Core check. Rejects any mint that would push foreign-held supply
     *         above the cap. Transfers between existing holders don't change
     *         total foreign-held supply in this POC, so they pass this module.
     * @dev A mint is signalled by _from == address(0) (ERC-3643/OZ convention).
     */
    function moduleCheck(
        address _from,
        address /*_to*/,
        uint256 _value,
        address _compliance
    ) external view override returns (bool) {
        // Only mints increase aggregate foreign-held supply in this model.
        if (_from == address(0)) {
            uint256 cap = _cap[_compliance];
            if (cap == 0) {
                // cap unset => treat as unconstrained (explicit opt-in required)
                return true;
            }
            uint256 supply = IToken(IModularCompliance(_compliance).getTokenBound()).totalSupply();
            if (supply + _value > cap) {
                return false; // would breach the foreign-ownership ceiling
            }
        }
        return true;
    }

    // No per-transfer state to maintain in this POC model.
    function moduleTransferAction(address _from, address _to, uint256 _value) external onlyComplianceCall {}

    // Mint succeeded: nothing to accumulate because we derive foreign-held from
    // totalSupply directly. A per-holder model would increment a tally here.
    function moduleMintAction(address _to, uint256 _value) external onlyComplianceCall {}

    function moduleBurnAction(address _from, uint256 _value) external onlyComplianceCall {}

    function canComplianceBind(address /*_compliance*/) external view override returns (bool) {
        return true;
    }

    function isPlugAndPlay() external pure override returns (bool) {
        return true;
    }

    function name() public pure returns (string memory) {
        return "ForeignOwnershipCapModule";
    }
}
