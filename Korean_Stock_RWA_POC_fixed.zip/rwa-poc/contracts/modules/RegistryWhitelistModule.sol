// SPDX-License-Identifier: GPL-3.0
pragma solidity ^0.8.17;

import "@tokenysolutions/t-rex/contracts/compliance/modular/modules/AbstractModuleUpgradeable.sol";

/**
 * @title RegistryWhitelistModule
 * @notice Korea-specific compliance module (W3 / Module B).
 *
 *  Enforces the myeong-ui-gaeseo (share-registry) whitelist: a token may only be
 *  received by an address whose legal shareholder status has been recorded in the
 *  Korean share registry (KSD linkage). This is a SEPARATE gate from the identity
 *  layer's isVerified():
 *
 *    - isVerified()  asks "is this a KYC'd, eligible investor?"  (ONCHAINID claims)
 *    - this module   asks "is this a registered shareholder?"    (registry linkage)
 *
 *  The whitelist is maintained by the registry-transfer authority defined by the
 *  regulatory track. This module only READS the list. Update authority is the
 *  bound compliance contract (which the Owner controls), standing in for the
 *  transfer-agent role in this POC.
 */
contract RegistryWhitelistModule is AbstractModuleUpgradeable {
    /// @dev compliance => (address => whitelisted as registered shareholder)
    mapping(address => mapping(address => bool)) private _registered;

    event RegistryStatusSet(address indexed compliance, address indexed holder, bool registered);

    function initialize() external initializer {
        __AbstractModule_init();
    }

    /**
     * @notice Add or remove an address from the share-registry whitelist.
     * @dev Callable only through the bound compliance contract. Represents the
     *      myeong-ui-gaeseo transfer being completed (or reversed) off-chain.
     */
    function setRegistered(address holder_, bool registered_) external onlyComplianceCall {
        _registered[msg.sender][holder_] = registered_;
        emit RegistryStatusSet(msg.sender, holder_, registered_);
    }

    function isRegistered(address compliance_, address holder_) external view returns (bool) {
        return _registered[compliance_][holder_];
    }

    /**
     * @notice Core check: the receiver must be a registered shareholder.
     * @dev Mints (`_from == address(0)`) must also target a registered address,
     *      so the initial investor is on the registry before tokens are created.
     */
    function moduleCheck(
        address /*_from*/,
        address _to,
        uint256 /*_value*/,
        address _compliance
    ) external view override returns (bool) {
        return _registered[_compliance][_to];
    }

    function moduleTransferAction(address _from, address _to, uint256 _value) external onlyComplianceCall {}
    function moduleMintAction(address _to, uint256 _value) external onlyComplianceCall {}
    function moduleBurnAction(address _from, uint256 _value) external onlyComplianceCall {}

    function canComplianceBind(address /*_compliance*/) external view override returns (bool) {
        return true;
    }

    function isPlugAndPlay() external pure override returns (bool) {
        return true;
    }

    function name() public pure returns (string memory) {
        return "RegistryWhitelistModule";
    }
}
