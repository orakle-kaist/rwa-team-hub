// SPDX-License-Identifier: GPL-3.0
pragma solidity ^0.8.17;

/**
 * This file exists only to pull ONCHAINID contracts into Hardhat's compilation,
 * so their artifacts are available to deploy from scripts via getContractFactory.
 * They are not used directly here.
 */
import "@onchain-id/solidity/contracts/Identity.sol";
import "@onchain-id/solidity/contracts/ClaimIssuer.sol";

// T-REX suite contracts we deploy from scripts:
import "@tokenysolutions/t-rex/contracts/registry/implementation/ClaimTopicsRegistry.sol";
import "@tokenysolutions/t-rex/contracts/registry/implementation/TrustedIssuersRegistry.sol";
import "@tokenysolutions/t-rex/contracts/registry/implementation/IdentityRegistryStorage.sol";
import "@tokenysolutions/t-rex/contracts/registry/implementation/IdentityRegistry.sol";
import "@tokenysolutions/t-rex/contracts/compliance/modular/ModularCompliance.sol";
import "@tokenysolutions/t-rex/contracts/token/Token.sol";
