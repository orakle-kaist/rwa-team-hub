// SPDX-License-Identifier: GPL-3.0
pragma solidity ^0.8.17;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/security/ReentrancyGuard.sol";

/**
 * @notice Minimal interface to the T-REX (ERC-3643) token this vault custodies.
 *         Only the functions the vault needs: mint/burn (agent-gated on the token
 *         side) and the standard ERC20 views.
 */
interface ITREXToken {
    function mint(address to, uint256 amount) external;
    function burn(address userAddress, uint256 amount) external;
    function totalSupply() external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
}

/**
 * @title AsyncEquityVault
 * @notice ERC-7540-STYLE asynchronous vault for a tokenized Korean equity (W2/W4/W5).
 *
 *  This is a teaching skeleton, not a full ERC-7540 implementation. It models the
 *  parts that matter for the POC narrative:
 *
 *    DEPOSIT  requestDeposit ──(escrow USDC, PENDING)──> fulfillDeposit (custodian
 *             buys share off-chain, mints T-REX token to vault, CLAIMABLE) ──>
 *             deposit/claim (investor receives vault shares, CLAIMED)
 *
 *    REDEEM   requestRedeem ──(lock shares, PENDING)──> fulfillRedeem (custodian
 *             sells share off-chain, burns T-REX token, returns USDC, CLAIMABLE)
 *             ──> withdraw/claim (investor receives USDC, CLAIMED)
 *
 *    DIVIDEND distributeDividend (custodian deposits net USDC per holder after
 *             treaty withholding) ──> claimDividend (pull).
 *
 *  Why async: Korean equities settle T+2 + FX, so the conversion price is fixed by
 *  the custodian at FULFILLMENT, not at request time. That also structurally
 *  defuses the ERC-4626 first-depositor inflation attack (price isn't computed on
 *  the spot from balances at deposit).
 *
 *  Roles:
 *    owner       = governance (sets custodian, dividend params)
 *    custodian   = the sole fulfiller; must also be an AGENT on the T-REX token so
 *                  its mint/burn calls succeed. (W6 constrained-agent decision.)
 *
 *  Accounting: vault "shares" are ERC20 units this contract issues. For the POC we
 *  fix 1 vault share == 1 underlying T-REX token (price 1.0), which keeps the demo
 *  legible; the conversion hooks are isolated so a NAV model can replace them.
 */
contract AsyncEquityVault is ERC20, Ownable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    // --- immutable wiring ---
    IERC20 public immutable usdc;            // payment asset (6 dp)
    ITREXToken public immutable shareToken;  // ERC-3643 underlying

    // --- roles ---
    address public custodian;

    // --- request state machines ---
    enum Status { NONE, PENDING, CLAIMABLE }

    struct DepositReq {
        uint256 usdcIn;     // escrowed USDC
        uint256 shares;     // shares made claimable at fulfillment
        Status  status;
    }
    struct RedeemReq {
        uint256 shares;     // locked shares
        uint256 usdcOut;    // USDC made claimable at fulfillment
        Status  status;
    }

    mapping(address => DepositReq) public depositReq;
    mapping(address => RedeemReq)  public redeemReq;

    // --- dividends (pull) ---
    mapping(address => uint256) public dividendClaimable; // net USDC owed to holder

    // --- events (these are the on-chain proof the demo prints) ---
    event DepositRequested(address indexed investor, uint256 usdcIn);
    event DepositFulfilled(address indexed investor, uint256 shares, uint256 pricePerShare);
    event DepositClaimed(address indexed investor, uint256 shares);
    event RedeemRequested(address indexed investor, uint256 shares);
    event RedeemFulfilled(address indexed investor, uint256 usdcOut);
    event RedeemClaimed(address indexed investor, uint256 usdcOut);
    event DividendDistributed(address indexed investor, uint256 grossUSDC, uint256 netUSDC, uint16 withheldBps);
    event DividendClaimed(address indexed investor, uint256 netUSDC);
    event CustodianSet(address indexed custodian);

    modifier onlyCustodian() {
        require(msg.sender == custodian, "vault: not custodian");
        _;
    }

    constructor(address usdc_, address shareToken_, address custodian_)
        ERC20("Vault Samsung Elec.", "vSEC")
    {
        usdc = IERC20(usdc_);
        shareToken = ITREXToken(shareToken_);
        custodian = custodian_;
        emit CustodianSet(custodian_);
    }

    function setCustodian(address custodian_) external onlyOwner {
        custodian = custodian_;
        emit CustodianSet(custodian_);
    }

    // 1 vault share == 1 underlying token in this POC (6dp USDC -> 18dp shares scaling handled in script sizing)
    function decimals() public pure override returns (uint8) {
        return 18;
    }

    // =====================================================================
    //                            DEPOSIT FLOW
    // =====================================================================

    /// @notice Investor commits USDC; it is escrowed and the request goes PENDING.
    function requestDeposit(uint256 usdcAmount) external nonReentrant {
        require(usdcAmount > 0, "vault: zero");
        require(depositReq[msg.sender].status == Status.NONE, "vault: deposit pending");

        usdc.safeTransferFrom(msg.sender, address(this), usdcAmount);
        depositReq[msg.sender] = DepositReq({usdcIn: usdcAmount, shares: 0, status: Status.PENDING});

        emit DepositRequested(msg.sender, usdcAmount);
    }

    /**
     * @notice Custodian settles a pending deposit AFTER buying the real share.
     *         Mints the ERC-3643 token to the vault (which triggers the token's
     *         identity + ForeignOwnershipCap checks), fixes the price, and makes
     *         the investor's vault shares claimable.
     * @param investor      the depositor being fulfilled
     * @param sharesToIssue vault shares (== tokens minted) at the fixed price
     */
    function fulfillDeposit(address investor, uint256 sharesToIssue)
        external
        onlyCustodian
        nonReentrant
    {
        DepositReq storage r = depositReq[investor];
        require(r.status == Status.PENDING, "vault: not pending");
        require(sharesToIssue > 0, "vault: zero shares");

        // Mint the underlying ERC-3643 token to the vault. This call runs the
        // token's compliance path (identity verified + foreign cap). If the cap
        // is breached, this reverts and the deposit stays PENDING (safe).
        shareToken.mint(address(this), sharesToIssue);

        r.shares = sharesToIssue;
        r.status = Status.CLAIMABLE;

        // pricePerShare here is nominal 1.0 (1e18) for the POC.
        emit DepositFulfilled(investor, sharesToIssue, 1e18);
    }

    /// @notice Investor claims the vault shares made available at fulfillment.
    function deposit() external nonReentrant {
        DepositReq storage r = depositReq[msg.sender];
        require(r.status == Status.CLAIMABLE, "vault: not claimable");

        uint256 shares = r.shares;
        delete depositReq[msg.sender];

        _mint(msg.sender, shares);
        emit DepositClaimed(msg.sender, shares);
    }

    // =====================================================================
    //                             REDEEM FLOW
    // =====================================================================

    /// @notice Investor requests redemption; shares are locked (moved to vault).
    function requestRedeem(uint256 shares) external nonReentrant {
        require(shares > 0, "vault: zero");
        require(redeemReq[msg.sender].status == Status.NONE, "vault: redeem pending");
        require(balanceOf(msg.sender) >= shares, "vault: insufficient shares");

        _transfer(msg.sender, address(this), shares); // lock
        redeemReq[msg.sender] = RedeemReq({shares: shares, usdcOut: 0, status: Status.PENDING});

        emit RedeemRequested(msg.sender, shares);
    }

    /**
     * @notice Custodian settles a redemption AFTER selling the real share.
     *         Burns the underlying ERC-3643 token from the vault and funds the
     *         USDC to be withdrawn. Custodian must have transferred `usdcOut`
     *         USDC to the vault (or the vault must already hold escrow).
     */
    function fulfillRedeem(address investor, uint256 usdcOut)
        external
        onlyCustodian
        nonReentrant
    {
        RedeemReq storage r = redeemReq[investor];
        require(r.status == Status.PENDING, "vault: not pending");

        // Burn the underlying token from the vault (burn bypasses eligibility).
        shareToken.burn(address(this), r.shares);

        // Burn the locked vault shares held by the vault.
        _burn(address(this), r.shares);

        r.usdcOut = usdcOut;
        r.status = Status.CLAIMABLE;

        emit RedeemFulfilled(investor, usdcOut);
    }

    /// @notice Investor withdraws the USDC proceeds made available at fulfillment.
    function withdraw() external nonReentrant {
        RedeemReq storage r = redeemReq[msg.sender];
        require(r.status == Status.CLAIMABLE, "vault: not claimable");

        uint256 amount = r.usdcOut;
        delete redeemReq[msg.sender];

        usdc.safeTransfer(msg.sender, amount);
        emit RedeemClaimed(msg.sender, amount);
    }

    // =====================================================================
    //                            DIVIDEND (PULL)
    // =====================================================================

    /**
     * @notice Custodian distributes a dividend to a holder, net of treaty
     *         withholding. The custodian must transfer `netUSDC` to the vault
     *         (or fund it beforehand). Pull pattern: holder claims later.
     * @param investor     dividend recipient
     * @param grossUSDC    gross dividend before withholding (for the event/audit)
     * @param withheldBps  withholding rate in basis points (e.g. 1500 = 15%)
     */
    function distributeDividend(address investor, uint256 grossUSDC, uint16 withheldBps)
        external
        onlyCustodian
        nonReentrant
    {
        require(withheldBps <= 10_000, "vault: bad bps");
        uint256 net = grossUSDC - (grossUSDC * withheldBps) / 10_000;

        usdc.safeTransferFrom(msg.sender, address(this), net);
        dividendClaimable[investor] += net;

        emit DividendDistributed(investor, grossUSDC, net, withheldBps);
    }

    /// @notice Holder pulls their accrued net dividend.
    function claimDividend() external nonReentrant {
        uint256 amount = dividendClaimable[msg.sender];
        require(amount > 0, "vault: nothing to claim");
        dividendClaimable[msg.sender] = 0;

        usdc.safeTransfer(msg.sender, amount);
        emit DividendClaimed(msg.sender, amount);
    }

    // =====================================================================
    //                              VIEWS
    // =====================================================================

    function totalAssets() external view returns (uint256) {
        return shareToken.balanceOf(address(this));
    }
}
