/**
 * deploy.js — stands up the full stack on the current network:
 *
 *   T-REX (ERC-3643) suite:
 *     ClaimTopicsRegistry, TrustedIssuersRegistry, IdentityRegistryStorage,
 *     IdentityRegistry, ModularCompliance, Token  (all init'd, non-proxy for
 *     skeleton simplicity), plus an onchain-id Identity per investor and a
 *     ClaimIssuer for the trusted VASP/KYC issuer.
 *
 *   Custom compliance modules:
 *     ForeignOwnershipCapModule (fires on mint path), RegistryWhitelistModule.
 *
 *   Payment + vault:
 *     MockUSDC, AsyncEquityVault.
 *
 * Returns an object of deployed handles for the runner script to drive.
 *
 * NOTE: T-REX contracts are upgradeable (they expect to sit behind proxies and be
 * initialized via init()). For a local skeleton we deploy the implementations and
 * call init() directly on them, which works for a single-instance demo. A
 * production deployment would use TREXFactory + proxies.
 */
const { ethers } = require("hardhat");

// ERC-734/735 claim constants
const CLAIM_TOPIC_KYC = 1n;               // our single required claim topic
const ISSUER_KEY_PURPOSE_CLAIM = 3n;      // CLAIM signer key purpose
const KEY_TYPE_ECDSA = 1n;

function addrToKey(addr) {
  return ethers.keccak256(ethers.AbiCoder.defaultAbiCoder().encode(["address"], [addr]));
}

async function deployIdentity(identityImplAuthorityOrNull, ownerAddr) {
  // Deploy an ONCHAINID Identity directly (library-managed proxy not needed for skeleton).
  const Identity = await ethers.getContractFactory(
    "@onchain-id/solidity/contracts/Identity.sol:Identity"
  );
  // constructor(initialManagementKey, isLibrary)
  const id = await Identity.deploy(ownerAddr, false);
  await id.waitForDeployment();
  return id;
}

async function main(log = () => {}) {
  const [deployer, custodian, alice, mallory] = await ethers.getSigners();

  log(`deployer:  ${deployer.address}`);
  log(`custodian: ${custodian.address}`);
  log(`alice:     ${alice.address}`);
  log(`mallory:   ${mallory.address} (ineligible actor for the enforcement test)`);

  // ---------------------------------------------------------------
  // 1. ONCHAINID: identity infra
  // ---------------------------------------------------------------
  // Trusted issuer (the VASP/KYC provider) needs its own identity + a claim key.
  const claimIssuerSigner = deployer; // deployer acts as the KYC/VASP signer
  const ClaimIssuer = await ethers.getContractFactory(
    "@onchain-id/solidity/contracts/ClaimIssuer.sol:ClaimIssuer"
  );
  const claimIssuer = await ClaimIssuer.deploy(claimIssuerSigner.address);
  await claimIssuer.waitForDeployment();
  log(`ClaimIssuer (VASP): ${await claimIssuer.getAddress()}`);

  // ---------------------------------------------------------------
  // 2. T-REX registries
  // ---------------------------------------------------------------
  const trex = (name) =>
    ethers.getContractFactory(`@tokenysolutions/t-rex/contracts/${name}`);

  const ClaimTopicsRegistry = await trex("registry/implementation/ClaimTopicsRegistry.sol:ClaimTopicsRegistry");
  const ctr = await ClaimTopicsRegistry.deploy();
  await ctr.waitForDeployment();
  await (await ctr.init()).wait();
  await (await ctr.addClaimTopic(CLAIM_TOPIC_KYC)).wait();

  const TrustedIssuersRegistry = await trex("registry/implementation/TrustedIssuersRegistry.sol:TrustedIssuersRegistry");
  const tir = await TrustedIssuersRegistry.deploy();
  await tir.waitForDeployment();
  await (await tir.init()).wait();
  await (await tir.addTrustedIssuer(await claimIssuer.getAddress(), [CLAIM_TOPIC_KYC])).wait();

  const IdentityRegistryStorage = await trex("registry/implementation/IdentityRegistryStorage.sol:IdentityRegistryStorage");
  const irs = await IdentityRegistryStorage.deploy();
  await irs.waitForDeployment();
  await (await irs.init()).wait();

  const IdentityRegistry = await trex("registry/implementation/IdentityRegistry.sol:IdentityRegistry");
  const ir = await IdentityRegistry.deploy();
  await ir.waitForDeployment();
  await (await ir.init(
    await tir.getAddress(),
    await ctr.getAddress(),
    await irs.getAddress()
  )).wait();

  // IdentityRegistry must be an agent of the storage to bind identities.
  await (await irs.addAgent(await ir.getAddress())).wait();

  log("T-REX registries deployed & initialized");

  // ---------------------------------------------------------------
  // 3. Modular compliance
  // ---------------------------------------------------------------
  const ModularCompliance = await trex("compliance/modular/ModularCompliance.sol:ModularCompliance");
  const compliance = await ModularCompliance.deploy();
  await compliance.waitForDeployment();
  await (await compliance.init()).wait();

  // ---------------------------------------------------------------
  // 4. Token (ERC-3643)
  // ---------------------------------------------------------------
  const Token = await trex("token/Token.sol:Token");
  const token = await Token.deploy();
  await token.waitForDeployment();

  // token identity (onchain-id for the token itself)
  const tokenIdentity = await deployIdentity(null, deployer.address);

  await (await token.init(
    await ir.getAddress(),
    await compliance.getAddress(),
    "Tokenized Samsung Electronics",
    "tSEC",
    18,
    await tokenIdentity.getAddress()
  )).wait();

  // bind the compliance to the token
  await (await compliance.bindToken(await token.getAddress())).wait();

  log(`ERC-3643 token: ${await token.getAddress()}`);

  // ---------------------------------------------------------------
  // 5. Custom compliance modules
  // ---------------------------------------------------------------
  const CapModule = await ethers.getContractFactory("ForeignOwnershipCapModule");
  const capModule = await CapModule.deploy();
  await capModule.waitForDeployment();
  await (await capModule.initialize()).wait();

  const WlModule = await ethers.getContractFactory("RegistryWhitelistModule");
  const wlModule = await WlModule.deploy();
  await wlModule.waitForDeployment();
  await (await wlModule.initialize()).wait();

  // add modules to compliance (order: cheap whitelist first, then cap)
  await (await compliance.addModule(await wlModule.getAddress())).wait();
  await (await compliance.addModule(await capModule.getAddress())).wait();

  log("custom modules deployed & registered (whitelist, foreign-cap)");

  // ---------------------------------------------------------------
  // 6. Payment + vault
  // ---------------------------------------------------------------
  const USDC = await ethers.getContractFactory("MockUSDC");
  const usdc = await USDC.deploy();
  await usdc.waitForDeployment();

  const Vault = await ethers.getContractFactory("AsyncEquityVault");
  const vault = await Vault.deploy(
    await usdc.getAddress(),
    await token.getAddress(),
    custodian.address
  );
  await vault.waitForDeployment();
  log(`vault: ${await vault.getAddress()}`);

  // ---------------------------------------------------------------
  // 7. Roles: token agents
  // ---------------------------------------------------------------
  // The vault must be a token AGENT so its mint/burn calls succeed (W6 decision).
  await (await token.addAgent(await vault.getAddress())).wait();
  // The custodian is also an agent (e.g. for administrative freeze/recovery).
  await (await token.addAgent(custodian.address)).wait();
  // The deployer needs the agent role to unpause the token.
  await (await token.addAgent(deployer.address)).wait();
  // IdentityRegistry needs an agent to register identities.
  await (await ir.addAgent(deployer.address)).wait();
  // unpause the token (T-REX tokens start paused)
  await (await token.unpause()).wait();

  log("roles wired: vault + custodian are token agents; token unpaused");

  // ---------------------------------------------------------------
  // 8. The vault holds the token, so the vault address must itself be
  //    identity-verified (T-REX requires mint recipients to pass isVerified).
  //    We give the vault an ONCHAINID with the same KYC claim, issued by the
  //    trusted VASP issuer, and register it (country 000 = institutional).
  // ---------------------------------------------------------------
  const vaultIdentity = await deployIdentity(null, deployer.address);
  const vaultIdAddr = await vaultIdentity.getAddress();
  const vaultAddr2 = await vault.getAddress();

  const claimData = ethers.hexlify(ethers.toUtf8Bytes("KYC:institutional-custody-vault"));
  const dataHash = ethers.keccak256(
    ethers.AbiCoder.defaultAbiCoder().encode(
      ["address", "uint256", "bytes"],
      [vaultIdAddr, CLAIM_TOPIC_KYC, claimData]
    )
  );
  const sig = await claimIssuerSigner.signMessage(ethers.getBytes(dataHash));
  // deployer manages the vault identity, so deployer adds the claim
  await (await vaultIdentity.connect(deployer).addClaim(
    CLAIM_TOPIC_KYC, 1, await claimIssuer.getAddress(), sig, claimData, ""
  )).wait();
  await (await ir.connect(deployer).registerIdentity(vaultAddr2, vaultIdAddr, 0)).wait();

  log("vault registered as a verified institutional identity (can hold tokens)");

  return {
    signers: { deployer, custodian, alice, mallory },
    claimIssuer, claimIssuerSigner,
    ctr, tir, irs, ir, compliance, token, tokenIdentity,
    capModule, wlModule, usdc, vault,
    constants: { CLAIM_TOPIC_KYC, ISSUER_KEY_PURPOSE_CLAIM, KEY_TYPE_ECDSA },
    helpers: { deployIdentity, addrToKey },
  };
}

module.exports = { main, deployIdentity, addrToKey, CLAIM_TOPIC_KYC };

// allow `hardhat run scripts/deploy.js`
if (require.main === module) {
  main((m) => console.log(m)).then(() => process.exit(0)).catch((e) => { console.error(e); process.exit(1); });
}
