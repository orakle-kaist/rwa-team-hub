/**
 * runDemo.js — executes the full tokenized-Korean-equity lifecycle on-chain and
 * prints each step with the real events emitted. Mirrors the interactive demo and
 * the W8 spec sequence diagram, but with actual mint/burn/transfer on a live chain.
 *
 *   run:  npx hardhat node          (terminal 1, optional for persistent chain)
 *         npm run demo              (terminal 2)   -> uses localhost
 *   or:   npm run demo:local        (in-process chain, one command)
 *
 * Scenario: Alice (foreign investor, Dubai, KR–US treaty) tokenizes Samsung Elec.
 */
const { ethers } = require("hardhat");
const { main: deploy } = require("./deploy");

// ---- pretty printing helpers ----
const C = {
  reset: "\x1b[0m", dim: "\x1b[2m", bold: "\x1b[1m",
  cyan: "\x1b[36m", green: "\x1b[32m", amber: "\x1b[33m",
  blue: "\x1b[34m", red: "\x1b[31m", gray: "\x1b[90m", mag: "\x1b[35m",
};
let STEP = 0;
function step(title) {
  STEP++;
  console.log(`\n${C.amber}${C.bold}── STEP ${String(STEP).padStart(2, "0")} · ${title} ${C.reset}`);
}
function say(msg) { console.log(`   ${msg}`); }
function ev(name, detail) { console.log(`   ${C.green}⛓  ${name}${C.reset} ${C.dim}${detail || ""}${C.reset}`); }
function note(msg) { console.log(`   ${C.gray}${msg}${C.reset}`); }

// 6-dp USDC and 18-dp shares/tokens
const usdc = (n) => ethers.parseUnits(n.toString(), 6);
const tok = (n) => ethers.parseUnits(n.toString(), 18);
const fUsdc = (v) => ethers.formatUnits(v, 6);
const fTok = (v) => ethers.formatUnits(v, 18);

async function balances(ctx, label) {
  const { usdc: U, token: T, vault: V, signers } = ctx;
  const a = signers.alice.address;
  const va = await V.getAddress();
  console.log(`   ${C.gray}┌ ${label}${C.reset}`);
  console.log(`   ${C.gray}│  Alice   USDC ${C.reset}${fUsdc(await U.balanceOf(a)).padStart(10)}   ${C.gray}vault-shares ${C.reset}${fTok(await V.balanceOf(a))}`);
  console.log(`   ${C.gray}│  Vault   USDC ${C.reset}${fUsdc(await U.balanceOf(va)).padStart(10)}   ${C.gray}holds tSEC   ${C.reset}${fTok(await T.balanceOf(va))}`);
  console.log(`   ${C.gray}└  tSEC totalSupply ${C.reset}${fTok(await T.totalSupply())}`);
}

async function main() {
  console.log(`${C.cyan}${C.bold}\n╔══════════════════════════════════════════════════════════════╗`);
  console.log(`║  Tokenized Korean Equity — On-chain Lifecycle (Level 2 POC)  ║`);
  console.log(`╚══════════════════════════════════════════════════════════════╝${C.reset}`);
  console.log(`${C.dim}ERC-3643 (T-REX) permissioned token · ERC-7540-style async vault · local Hardhat${C.reset}`);

  // ============ DEPLOY ============
  step("Deploy & wire the stack");
  const ctx = await deploy((m) => note(m));
  const { signers, token, ir, compliance, capModule, wlModule, usdc: USDC, vault,
          claimIssuer, claimIssuerSigner, tokenIdentity, helpers, constants } = ctx;
  const { deployIdentity } = helpers;
  const { CLAIM_TOPIC_KYC } = constants;
  const alice = signers.alice, custodian = signers.custodian, deployer = signers.deployer;

  const vaultAddr = await vault.getAddress();
  const complianceAddr = await compliance.getAddress();

  // ============ CONFIGURE POLICY ============
  step("Set compliance policy (foreign cap + registry whitelist)");
  // Foreign ownership cap: max 100 tokens of foreign-held supply for this stock.
  await (await compliance.callModuleFunction(
    capModule.interface.encodeFunctionData("setForeignCap", [tok(100)]),
    await capModule.getAddress()
  )).wait();
  say(`Foreign-ownership cap set to ${C.bold}100 tSEC${C.reset} (max foreign-held supply)`);
  note("In production this tracks an oracle feed of the aggregate foreign float.");

  // Whitelist the vault as a registered holder (tokens live in the vault).
  await (await compliance.callModuleFunction(
    wlModule.interface.encodeFunctionData("setRegistered", [vaultAddr, true]),
    await wlModule.getAddress()
  )).wait();
  say(`Vault added to the myeong-ui-gaeseo (share-registry) whitelist`);

  // ============ ONBOARDING ============
  step("Onboard Alice — ONCHAINID + KYC claim");
  // Alice gets an on-chain identity.
  const aliceId = await deployIdentity(null, alice.address);
  const aliceIdAddr = await aliceId.getAddress();
  say(`Alice ONCHAINID deployed: ${C.dim}${aliceIdAddr}${C.reset}`);

  // The trusted issuer (VASP) signs a KYC claim for Alice's identity.
  const claimData = ethers.hexlify(ethers.toUtf8Bytes("KYC:passed;foreign-reg:FSS;tax:KR-US-15"));
  const claimIssuerAddr = await claimIssuer.getAddress();
  // ONCHAINID claim signature = sign(keccak256(abi.encode(identity, topic, data)))
  const dataHash = ethers.keccak256(
    ethers.AbiCoder.defaultAbiCoder().encode(
      ["address", "uint256", "bytes"],
      [aliceIdAddr, CLAIM_TOPIC_KYC, claimData]
    )
  );
  const sig = await claimIssuerSigner.signMessage(ethers.getBytes(dataHash));
  // add claim to Alice's identity (scheme 1 = ECDSA)
  await (await aliceId.connect(alice).addClaim(
    CLAIM_TOPIC_KYC, 1, claimIssuerAddr, sig, claimData, ""
  )).wait();
  ev("Claim added", "KYC (topic 1) signed by trusted VASP issuer");

  // Register Alice in the IdentityRegistry (country code 784 = UAE).
  await (await ir.connect(deployer).registerIdentity(alice.address, aliceIdAddr, 784)).wait();
  ev("registerIdentity", "Alice ↔ ONCHAINID, country=784 (UAE)");
  say(`isVerified(Alice) = ${C.green}${await ir.isVerified(alice.address)}${C.reset}`);

  // Alice must also be on the registry whitelist to eventually hold/redeem via vault flows.
  await (await compliance.callModuleFunction(
    wlModule.interface.encodeFunctionData("setRegistered", [alice.address, true]),
    await wlModule.getAddress()
  )).wait();
  note("Alice whitelisted as a registered shareholder (separate gate from KYC).");

  // ============ FUND ALICE ============
  step("Fund Alice with USDC (simulated on-ramp)");
  await (await USDC.mint(alice.address, usdc(10000))).wait();
  ev("USDC.mint", `10,000 USDC → Alice`);
  await balances(ctx, "opening balances");

  // ============ DEPOSIT REQUEST ============
  step("requestDeposit — Alice commits 10,000 USDC");
  await (await USDC.connect(alice).approve(vaultAddr, usdc(10000))).wait();
  const rd = await (await vault.connect(alice).requestDeposit(usdc(10000))).wait();
  ev("DepositRequested", "10,000 USDC escrowed · state = PENDING");
  note("No shares exist yet. The vault waits while the custodian settles off-chain.");

  // ============ OFF-CHAIN SETTLEMENT (simulated) ============
  step("Off-chain: custodian buys the real share (T+2 + FX)");
  note("USDC → KRW conversion, buy Samsung shares on KRX, T+2 settlement.");
  note("(Simulated as elapsed time; on a testnet you'd advance blocks/time here.)");

  // ============ FULFILL DEPOSIT (mint through compliance) ============
  step("fulfillDeposit — custodian mints tSEC through compliance");
  say(`Minting ${C.bold}100 tSEC${C.reset} to the vault (price fixed at fulfillment).`);
  say(`This runs the token's compliance path:`);
  note("  · gate 1  not frozen");
  note("  · gate 2  isVerified (identity)  ✓");
  note("  · gate 3  foreign-ownership cap  32→? checked ON THE MINT PATH  ✓");
  const ff = await (await vault.connect(custodian).fulfillDeposit(alice.address, tok(100))).wait();
  ev("Token.Transfer", "mint 100 tSEC → vault (0x0 → vault)");
  ev("DepositFulfilled", "shares=100 · pricePerShare=1.0 · state = CLAIMABLE");
  note(`tSEC totalSupply now ${fTok(await token.totalSupply())} / cap 100 — at the ceiling.`);

  // ============ CLAIM SHARES ============
  step("deposit (claim) — Alice receives vault shares");
  await (await vault.connect(alice).deposit()).wait();
  ev("DepositClaimed", "100 vSEC → Alice · state = CLAIMED");
  await balances(ctx, "after deposit settles");

  // ============ DIVIDEND ============
  step("Dividend — Samsung pays; 15% KR–US treaty withheld");
  // custodian funds and distributes: gross 300 USDC, 15% withheld => net 255
  await (await USDC.mint(custodian.address, usdc(300))).wait();
  await (await USDC.connect(custodian).approve(vaultAddr, usdc(300))).wait();
  await (await vault.connect(custodian).distributeDividend(alice.address, usdc(300), 1500)).wait();
  ev("DividendDistributed", "gross=300 · withheld=15% · net=255 USDC");
  note("Withholding is per-investor (treaty residency), so dividends are NOT blended into share price.");
  await (await vault.connect(alice).claimDividend()).wait();
  ev("DividendClaimed", "255 USDC → Alice");

  // ============ REDEEM REQUEST ============
  step("requestRedeem — Alice exits");
  await (await vault.connect(alice).requestRedeem(tok(100))).wait();
  ev("RedeemRequested", "100 vSEC locked · state = PENDING");

  // ============ OFF-CHAIN SELL ============
  step("Off-chain: custodian sells the share, returns USDC");
  note("Sell Samsung on KRX, KRW → USDC, T+2. Custodian funds the vault with proceeds.");
  await (await USDC.mint(custodian.address, usdc(10000))).wait();
  await (await USDC.connect(custodian).transfer(vaultAddr, usdc(10000))).wait();
  note("10,000 USDC proceeds transferred to vault (simulated).");

  // ============ FULFILL REDEEM (burn) ============
  step("fulfillRedeem — custodian burns tSEC");
  await (await vault.connect(custodian).fulfillRedeem(alice.address, usdc(10000))).wait();
  ev("Token.Transfer", "burn 100 tSEC from vault (vault → 0x0)");
  ev("RedeemFulfilled", "usdcOut=10,000 · state = CLAIMABLE");
  note(`tSEC totalSupply back to ${fTok(await token.totalSupply())} — foreign ownership released.`);

  // ============ WITHDRAW ============
  step("withdraw (claim) — USDC returns to Alice");
  await (await vault.connect(alice).withdraw()).wait();
  ev("RedeemClaimed", "10,000 USDC → Alice · state = CLAIMED");
  await balances(ctx, "final balances");

  // ============ SUMMARY ============
  console.log(`\n${C.green}${C.bold}✓ Full lifecycle complete.${C.reset}`);
  console.log(`${C.dim}  deposit → fulfil/mint → claim → dividend → redeem → burn → withdraw${C.reset}`);
  const aliceFinalUsdc = fUsdc(await USDC.balanceOf(alice.address));
  console.log(`${C.dim}  Alice began with 10,000 USDC, earned 255 net dividend, ended with ${aliceFinalUsdc} USDC.${C.reset}`);

  // The enforcement proof (over-cap mint reverts with "Compliance not
  // followed") and the registry-gate proof now live in the proper test suite:
  //     npm test        (test/lifecycle.test.js)
}

main().then(() => process.exit(0)).catch((e) => { console.error(e); process.exit(1); });
