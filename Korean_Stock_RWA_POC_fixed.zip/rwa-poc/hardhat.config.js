require("@nomicfoundation/hardhat-toolbox");
const { subtask } = require("hardhat/config");
const { TASK_COMPILE_SOLIDITY_GET_SOLC_BUILD } = require("hardhat/builtin-tasks/task-names");
const path = require("path");

/**
 * Offline compiler resolution. We point Hardhat at the npm-installed `solc`
 * package (pinned to exactly 0.8.17 in package.json — T-REX and ONCHAINID use
 * `pragma solidity 0.8.17;`, so the version must match exactly). This makes
 * `compile` work without reaching binaries.soliditylang.org.
 *
 * The override only fires if the local package is actually the 0.8.17 build;
 * otherwise it falls through to Hardhat's normal compiler download. (Note:
 * hardhat itself pulls in a NEWER `solc` transitively, so the explicit
 * `"solc": "0.8.17"` pin in package.json is load-bearing — without it, the
 * hoisted copy is 0.8.26 and compilation of the pinned-pragma deps fails.)
 */
subtask(TASK_COMPILE_SOLIDITY_GET_SOLC_BUILD, async (args, hre, runSuper) => {
  if (args.solcVersion === "0.8.17") {
    try {
      const solcVersion = require("solc/package.json").version;
      if (solcVersion === "0.8.17") {
        return {
          compilerPath: path.join(__dirname, "node_modules", "solc", "soljson.js"),
          isSolcJs: true,
          version: "0.8.17",
          longVersion: "0.8.17+commit.8df45f5f",
        };
      }
    } catch (_) {
      // solc not installed locally — fall through to Hardhat's downloader
    }
  }
  return runSuper(args);
});

/**
 * Everything (T-REX deps and our contracts) compiles under 0.8.17 — T-REX and
 * ONCHAINID pin that version exactly, and our contracts use `pragma ^0.8.17`.
 * viaIR is enabled because T-REX + OZ upgradeable can hit "stack too deep".
 */
module.exports = {
  solidity: {
    version: "0.8.17",
    settings: {
      optimizer: { enabled: true, runs: 200 },
      viaIR: true,
    },
  },
  networks: {
    // In-process chain used when no --network is passed.
    hardhat: {
      allowUnlimitedContractSize: true,
    },
    // Persistent local node: `npm run chain` then `npm run demo`.
    localhost: {
      url: "http://127.0.0.1:8545",
      allowUnlimitedContractSize: true,
    },
  },
};
