# Korean Stock RWA — Level 2 On-chain POC

A runnable skeleton demonstrating the Asset Tokenization & Custody track's design:
a **permissioned ERC-3643 (T-REX) share token** custodied by an **ERC-7540-style
asynchronous vault**, driven through the full lifecycle by a command-line script
that emits real on-chain events.

This is the "Level 2" demo: real contracts on a local chain, not a UI mockup.

---

## What it does

The demo (`scripts/runDemo.js`) walks one tokenized Samsung Electronics position
through the entire lifecycle for **Alice**, a foreign investor (Dubai, KR–US tax
treaty):

```
deploy → set policy → onboard (ONCHAINID + KYC) → fund USDC
→ requestDeposit → (off-chain T+2) → fulfillDeposit (mint through compliance)
→ claim shares → dividend (15% treaty withholding) → requestRedeem
→ (off-chain sell) → fulfillRedeem (burn) → withdraw
```

Every step prints the real events emitted (`DepositRequested`, `Token.Transfer`
mint/burn, `DividendDistributed`, etc.).

### The two custom contracts (what this track actually writes)

Everything else is forked; these are the track's own code:

- **`contracts/modules/ForeignOwnershipCapModule.sol`** — enforces the statutory
  foreign-ownership ceiling. Crucially, it fires **on the mint path** (detected via
  `_from == address(0)`), closing the W3 "mint trap" where standard T-REX skips
  compliance on mint. A regulatory limit enforced in code, not by diligence.
- **`contracts/modules/RegistryWhitelistModule.sol`** — the myeong-ui-gaeseo
  (share-registry) whitelist; a separate gate from KYC identity verification.
- **`contracts/vault/AsyncEquityVault.sol`** — the ERC-7540-style async vault:
  request → pending → claimable → claimed, for both deposit and redeem, plus
  pull-based dividends with per-investor withholding.

---

## Requirements

- Node.js 18+ (tested on 22)
- npm

## Setup

```bash
npm install
```

That's it — `solc@0.8.17` is pinned in `devDependencies`, so compilation works
offline and on machines that can't reach `binaries.soliditylang.org`.

## Run the demo

Simplest (in-process chain, one command):

```bash
npm run demo:local
```

Or against a persistent local node (two terminals):

```bash
# terminal 1
npm run chain          # starts hardhat node on 127.0.0.1:8545

# terminal 2
npm run demo           # runs the lifecycle against localhost
```

## Compile only

```bash
npm run compile
```

---

## Tests (the proof artifacts)

```bash
npm test
```

`test/lifecycle.test.js` covers:

1. **Happy path** — the full deposit → mint → claim → dividend → redeem →
   burn → withdraw lifecycle with balance and event assertions.
2. **Enforcement (the W3 "mint trap" closed)** — a `fulfillDeposit` for 101 tSEC
   against a 100 tSEC cap reverts with `Compliance not followed`, and even a
   1-wei direct agent mint at the ceiling is rejected. The foreign-ownership
   cap is enforced **on the mint path**, in code, not by custodian diligence.
   This is often the most convincing artifact for a compliance-minded audience,
   because it shows the permissioned token *rejecting* a disallowed action.
3. **Registry gate ≠ KYC gate** — a fully KYC-verified investor who is *not*
   on the share-registry (myeong-ui-gaeseo) whitelist still cannot receive
   tokens, proving the two gates are independent.

---

## Notes & caveats

- **Simulated, not production.** Vault accounting fixes 1 vault share = 1 underlying
  token (price 1.0) for legibility; a NAV model would replace `convertToShares` /
  `convertToAssets`. Off-chain settlement (T+2, FX, buying/selling the real share)
  is represented by elapsed steps and simulated USDC funding — on a testnet you'd
  advance time/blocks and fund from a real account.
- **The vault is a verified identity.** Because the vault *holds* the ERC-3643
  token, its address must itself pass `isVerified`; the deploy script registers it
  with an institutional ONCHAINID. This is a real T-REX property, not a workaround.
- **Non-proxy deployment.** T-REX contracts are upgradeable and normally sit behind
  proxies deployed via `TREXFactory`. For a single-instance skeleton we deploy the
  implementations and call `init()` directly. A production deployment would use the
  factory + proxies.
- **`hardhat.config.js` contains an offline-solc override.** It points Hardhat at
  the npm-installed `solc` package (pinned to exactly `0.8.17` in `package.json`
  — this pin is required, because hardhat transitively installs a newer `solc`
  that cannot compile T-REX's exact-pinned `pragma solidity 0.8.17;`). The
  override checks the installed version and falls back to Hardhat's normal
  compiler download if it doesn't match, so it is safe on any machine.
- **Known Phase-2 gaps (deliberate POC simplifications):**
  (a) *Escrow sweep* — `requestDeposit` escrows USDC in the vault but nothing
  forwards it to the custodian to fund the off-chain purchase; a production
  `fulfillDeposit` would transfer `usdcIn` out (or expose a sweep).
  (b) *Vault-share transferability* — `vSEC` is a plain ERC20, so the economic
  claim on the permissioned `tSEC` is freely transferable; a production vault
  would gate share transfers against the same IdentityRegistry.
  (c) *No cancellation path* — a PENDING request cannot be cancelled if the
  custodian never fulfills; ERC-7540's optional cancel flows would cover this.

## Dependency versions (pinned for compatibility)

- `@tokenysolutions/t-rex@4.1.6` (ERC-3643 reference implementation)
- `@onchain-id/solidity@2.2.1` (ONCHAINID)
- `@openzeppelin/contracts@4.9.6` + `@openzeppelin/contracts-upgradeable@4.9.6`
  (v4.9 is required — T-REX 4.1.6 is not compatible with OZ v5)
- `solc@0.8.17` (exact pin — see the offline-solc caveat above)
- Solidity 0.8.17

---

## Layout

```
contracts/
  modules/
    ForeignOwnershipCapModule.sol   ← custom (fires on mint path)
    RegistryWhitelistModule.sol     ← custom (share-registry whitelist)
  vault/
    AsyncEquityVault.sol            ← custom (ERC-7540-style async vault)
  mocks/
    MockUSDC.sol                    ← 6-dp stablecoin stand-in
    Imports.sol                     ← forces T-REX + ONCHAINID artifact compilation
scripts/
  deploy.js                         ← stands up + wires the full stack
  runDemo.js                        ← the step-by-step lifecycle runner
test/
  lifecycle.test.js                 ← happy path + enforcement + registry-gate tests
hardhat.config.js
package.json
```

Map to the design docs: W1/W2 = standard choice; W3 = the two modules + mint/burn;
W4/W5 = the vault + async state machine; W6 = roles wiring in `deploy.js`; W7 = the
end-to-end flow in `runDemo.js`.
