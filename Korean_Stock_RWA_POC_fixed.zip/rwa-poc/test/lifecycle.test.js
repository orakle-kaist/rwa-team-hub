/**
 * lifecycle.test.js — the repo's proof artifacts as a proper test suite.
 *
 *   1. Happy path: the full deposit → mint → claim → dividend → redeem →
 *      burn → withdraw lifecycle, asserting balances and request state at
 *      each stage.
 *   2. Enforcement (the W3 "mint trap" closed): a fulfillDeposit that would
 *      push foreign-held supply over the cap MUST revert with
 *      "Compliance not followed" — the cap is enforced on the mint path,
 *      in code, not by custodian diligence.
 *   3. Registry gate: a transfer to a non-registered (non-myeong-ui-gaeseo)
 *      address is rejected even for a KYC-verified receiver, proving the
 *      whitelist is a separate gate from identity verification.
 *
 * Run: npm test
 */
const { expect } = require("chai");
const { ethers } = require("hardhat");
const { loadFixture } = require("@nomicfoundation/hardhat-toolbox/network-helpers");
const { main: deploy } = require("../scripts/deploy");

const usdc = (n) => ethers.parseUnits(n.toString(), 6);
const tok = (n) => ethers.parseUnits(n.toString(), 18);

const FOREIGN_CAP = tok(100);

/** Onboard an EOA: ONCHAINID + issuer-signed KYC claim + registry entry + whitelist. */
async function onboard(ctx, signer, countryCode) {
  const { ir, compliance, wlModule, claimIssuer, claimIssuerSigner, helpers, constants, signers } = ctx;
  const { CLAIM_TOPIC_KYC } = constants;

  const id = await helpers.deployIdentity(null, signer.address);
  const idAddr = await id.getAddress();

  const claimData = ethers.hexlify(ethers.toUtf8Bytes("KYC:passed"));
  const dataHash = ethers.keccak256(
    ethers.AbiCoder.defaultAbiCoder().encode(
      ["address", "uint256", "bytes"],
      [idAddr, CLAIM_TOPIC_KYC, claimData]
    )
  );
  const sig = await claimIssuerSigner.signMessage(ethers.getBytes(dataHash));
  await (await id.connect(signer).addClaim(
    CLAIM_TOPIC_KYC, 1, await claimIssuer.getAddress(), sig, claimData, ""
  )).wait();
  await (await ir.connect(signers.deployer).registerIdentity(signer.address, idAddr, countryCode)).wait();

  await (await compliance.callModuleFunction(
    wlModule.interface.encodeFunctionData("setRegistered", [signer.address, true]),
    await wlModule.getAddress()
  )).wait();

  return id;
}

/** Deploy the whole stack, set the policy, onboard Alice. */
async function deployedFixture() {
  const ctx = await deploy();
  const { compliance, capModule, wlModule, vault } = ctx;
  const vaultAddr = await vault.getAddress();

  // policy: foreign-ownership cap + vault on the share-registry whitelist
  await (await compliance.callModuleFunction(
    capModule.interface.encodeFunctionData("setForeignCap", [FOREIGN_CAP]),
    await capModule.getAddress()
  )).wait();
  await (await compliance.callModuleFunction(
    wlModule.interface.encodeFunctionData("setRegistered", [vaultAddr, true]),
    await wlModule.getAddress()
  )).wait();

  // onboard Alice (foreign investor, UAE = 784)
  await onboard(ctx, ctx.signers.alice, 784);

  return ctx;
}

describe("Korean Stock RWA POC", function () {
  describe("full lifecycle (happy path)", function () {
    it("walks deposit → mint → claim → dividend → redeem → burn → withdraw", async function () {
      const ctx = await loadFixture(deployedFixture);
      const { usdc: USDC, token, vault, signers } = ctx;
      const { alice, custodian } = signers;
      const vaultAddr = await vault.getAddress();

      // fund + requestDeposit
      await (await USDC.mint(alice.address, usdc(10_000))).wait();
      await (await USDC.connect(alice).approve(vaultAddr, usdc(10_000))).wait();
      await expect(vault.connect(alice).requestDeposit(usdc(10_000)))
        .to.emit(vault, "DepositRequested").withArgs(alice.address, usdc(10_000));
      expect(await USDC.balanceOf(vaultAddr)).to.equal(usdc(10_000)); // escrowed

      // fulfillDeposit mints tSEC to the vault THROUGH compliance
      await expect(vault.connect(custodian).fulfillDeposit(alice.address, tok(100)))
        .to.emit(token, "Transfer").withArgs(ethers.ZeroAddress, vaultAddr, tok(100));
      expect(await token.totalSupply()).to.equal(tok(100)); // at the cap

      // claim vault shares
      await expect(vault.connect(alice).deposit())
        .to.emit(vault, "DepositClaimed").withArgs(alice.address, tok(100));
      expect(await vault.balanceOf(alice.address)).to.equal(tok(100));

      // dividend: gross 300, 15% treaty withholding => net 255
      await (await USDC.mint(custodian.address, usdc(300))).wait();
      await (await USDC.connect(custodian).approve(vaultAddr, usdc(300))).wait();
      await expect(vault.connect(custodian).distributeDividend(alice.address, usdc(300), 1500))
        .to.emit(vault, "DividendDistributed")
        .withArgs(alice.address, usdc(300), usdc(255), 1500);
      await expect(vault.connect(alice).claimDividend())
        .to.emit(vault, "DividendClaimed").withArgs(alice.address, usdc(255));
      expect(await USDC.balanceOf(alice.address)).to.equal(usdc(255));

      // redeem: lock shares, custodian sells off-chain, burns, funds proceeds
      await expect(vault.connect(alice).requestRedeem(tok(100)))
        .to.emit(vault, "RedeemRequested").withArgs(alice.address, tok(100));
      await (await USDC.mint(custodian.address, usdc(10_000))).wait();
      await (await USDC.connect(custodian).transfer(vaultAddr, usdc(10_000))).wait();
      await expect(vault.connect(custodian).fulfillRedeem(alice.address, usdc(10_000)))
        .to.emit(token, "Transfer").withArgs(vaultAddr, ethers.ZeroAddress, tok(100)); // burn
      expect(await token.totalSupply()).to.equal(0n); // foreign ownership released

      // withdraw proceeds
      await expect(vault.connect(alice).withdraw())
        .to.emit(vault, "RedeemClaimed").withArgs(alice.address, usdc(10_000));
      expect(await USDC.balanceOf(alice.address)).to.equal(usdc(10_255));
      expect(await vault.balanceOf(alice.address)).to.equal(0n);
    });
  });

  describe("enforcement: foreign-ownership cap on the mint path", function () {
    it("reverts an over-cap mint with 'Compliance not followed'", async function () {
      const ctx = await loadFixture(deployedFixture);
      const { usdc: USDC, vault, signers } = ctx;
      const { alice, custodian } = signers;
      const vaultAddr = await vault.getAddress();

      await (await USDC.mint(alice.address, usdc(10_000))).wait();
      await (await USDC.connect(alice).approve(vaultAddr, usdc(10_000))).wait();
      await (await vault.connect(alice).requestDeposit(usdc(10_000))).wait();

      // cap is 100 tSEC; 101 must be rejected by the compliance module AT MINT
      await expect(
        vault.connect(custodian).fulfillDeposit(alice.address, tok(101))
      ).to.be.revertedWith("Compliance not followed");

      // the deposit stays PENDING (safe): fulfilling within the cap still works
      await expect(vault.connect(custodian).fulfillDeposit(alice.address, tok(100)))
        .to.emit(vault, "DepositFulfilled");
    });

    it("mints exactly at the cap succeed; one unit above fails", async function () {
      const ctx = await loadFixture(deployedFixture);
      const { usdc: USDC, vault, token, signers } = ctx;
      const { alice, custodian } = signers;
      const vaultAddr = await vault.getAddress();

      await (await USDC.mint(alice.address, usdc(10_000))).wait();
      await (await USDC.connect(alice).approve(vaultAddr, usdc(10_000))).wait();
      await (await vault.connect(alice).requestDeposit(usdc(10_000))).wait();
      await (await vault.connect(custodian).fulfillDeposit(alice.address, tok(100))).wait();
      expect(await token.totalSupply()).to.equal(FOREIGN_CAP);

      // supply is at the ceiling: even a 1-wei mint by a direct token agent reverts
      await expect(
        token.connect(custodian).mint(vaultAddr, 1n)
      ).to.be.revertedWith("Compliance not followed");
    });
  });

  describe("registry whitelist: a separate gate from KYC", function () {
    it("rejects transfers to a KYC-verified but non-registered receiver", async function () {
      const ctx = await loadFixture(deployedFixture);
      const { usdc: USDC, token, ir, compliance, wlModule, vault, signers } = ctx;
      const { alice, custodian, mallory } = signers;
      const vaultAddr = await vault.getAddress();

      // Mint 50 tSEC into the vault via a fulfilled deposit
      await (await USDC.mint(alice.address, usdc(5_000))).wait();
      await (await USDC.connect(alice).approve(vaultAddr, usdc(5_000))).wait();
      await (await vault.connect(alice).requestDeposit(usdc(5_000))).wait();
      await (await vault.connect(custodian).fulfillDeposit(alice.address, tok(50))).wait();

      // Onboard Mallory with FULL KYC (identity verified)...
      await onboard(ctx, mallory, 840);
      expect(await ir.isVerified(mallory.address)).to.equal(true);

      // ...then REMOVE her from the share registry only.
      await (await compliance.callModuleFunction(
        wlModule.interface.encodeFunctionData("setRegistered", [mallory.address, false]),
        await wlModule.getAddress()
      )).wait();

      // KYC passes, registry gate blocks: custodian (token agent) cannot even
      // forced-mint to her, and a compliance-path transfer is rejected.
      await expect(
        token.connect(custodian).mint(mallory.address, tok(1))
      ).to.be.revertedWith("Compliance not followed");
    });
  });
});
